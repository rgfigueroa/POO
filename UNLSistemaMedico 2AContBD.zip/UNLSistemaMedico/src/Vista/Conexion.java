/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 *
 * @author roberth
 */
public class Conexion {

    Connection con;

    public Conexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/BD2B", "root", "root");
            System.out.println("Driver cargado correctamente");
        } catch (Exception e) {
            System.err.println("No se encuentra el Driver de conexion a la DB:" + e);
        }
    }

    public static void main(String[] args) {
        Conexion cn = new Conexion();
        System.out.println("Comenzando una consulta");
        Statement st;
        ResultSet rs;
        try {
            st = cn.con.createStatement();
            System.out.println("Se ha creado la Sentencia SQL");
            rs = st.executeQuery("select * from producto");
            System.out.println("Se ejecuta la sentencia en la BD y mostramos el resultado\n");
            while (rs.next()) {
                System.out.println(rs.getString("idproducto") + "\t"
                        + rs.getString("nombre") + "\t" + rs.getString("descripcion") + "\t"
                        + rs.getInt("cantidad") + "\t" + rs.getDouble("precio") + "\t" + rs.getString("marca"));
            }
            cn.con.close();
        } catch (Exception e) {
        }
    }
}
