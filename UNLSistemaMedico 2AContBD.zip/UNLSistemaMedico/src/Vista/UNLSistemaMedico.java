/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.ControladorEmpleado;
import Controlador.ControladorMedico;
import Controlador.ControladorPaciente;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 *
 * @author roberth
 */
public class UNLSistemaMedico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);
        System.out.println("Ingresar Anio de nacimeinto:");
        Date fechaNacimiento = new Date();

        int anioNacimiento = sc.nextInt();

        fechaNacimiento.setYear(anioNacimiento - 1900);

        Date fechaActual = new Date();

        int anioActual = 1900 + fechaActual.getYear();
        System.out.println("Anio actual:" + anioActual);
        System.out.println("EDAD ACTUAL: " + (anioActual - anioNacimiento));

        Controlador.ControladorEmpleado ctrlEmpleado = new ControladorEmpleado("Empleado ABC", fechaActual, 100.50);
        ctrlEmpleado.calcularEdadActual(fechaNacimiento, fechaActual);

        Controlador.ControladorPersona ctrlPersona = new Controlador.ControladorPersona("Persona ABC", fechaActual);
        ctrlPersona.calcularEdadActual(fechaNacimiento, fechaActual);

        Controlador.ControladorPaciente ctrlPaciente = new Controlador.ControladorPaciente("Nom", fechaActual);
        int edad = ctrlPaciente.calcularEdadActual(fechaNacimiento, fechaActual);
        System.out.println("EDAD RETORNO:" + edad);

        ControladorMedico ctrlMedico = new ControladorMedico("Dr. Perez", fechaActual, 200.00, 54207);
        ctrlMedico.calcularEdadActual(fechaNacimiento, fechaActual);

    }

}
